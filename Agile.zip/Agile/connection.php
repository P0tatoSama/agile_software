<?php
	//if the server is our PC,then will be localhost. If our server is elsewhere, for instance Azure or others, then may be the name of the address
	//Address of localhost : 127.0.01
	//Establishing connection
	$connect = mysqli_connect('localhost','root','','agile_algorithm5');
?>