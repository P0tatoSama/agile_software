vti_encoding:SR|utf8-nl
vti_author:SR|DESKTOP-63M1S5G\\phili
vti_modifiedby:SR|DESKTOP-63M1S5G\\phili
vti_timelastmodified:TR|12 Nov 2019 18:36:38 -0000
vti_timecreated:TR|12 Nov 2019 18:22:41 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|default.php review.php relevant.php rating.php
vti_nexttolasttimemodified:TW|12 Nov 2019 18:22:45 -0000
vti_cacheddtm:TX|12 Nov 2019 18:36:39 -0000
vti_filesize:IR|3873
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css H|default.php A|relevant.php A|rating.php A|review.php
vti_cachedsvcrellinks:VX|NQSS|https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css FHUS|default.php FAUS|relevant.php FAUS|rating.php FAUS|review.php
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
