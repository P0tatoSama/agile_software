  
##### Providing pre-made builds:  
 
- __core build__: Abilities_Hats_Couriers_Wards  
- __extended build__: Abilities_Hats_Couriers_Wards_HEROES_MagusCypher  
- __full build__: Abilities_Hats_Couriers_Wards_HEROES_MagusCypher_Seasonal_Base_Effigies_Shrines_Terrain_Menu  
*recommended for Potato PC, up to 15-20% fps increase on the lower end*  

#### How to manually install No-Bling DOTA mod builds in 2019:  
   ~ CREATE FOLDER `\steamapps\common\dota 2 beta\game\dota_tempcontent`  
   ~ COPY `pak01_dir.vpk` IN `\steamapps\common\dota 2 beta\game\dota_tempcontent`  
   ~ ADD LAUNCH OPTION: `-tempcontent`  

Use [No-Bling DOTA mod builder.bat](https://github.com/No-Bling/DOTA/blob/master/No-Bling%20DOTA%20mod%20builder.zip) instead if possible, to generate updated custom build with automatic install!  

