-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2019 at 06:39 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agile_algorithm5`
--

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `Location_ID` int(11) NOT NULL,
  `Location_Name` varchar(60) DEFAULT NULL,
  `Location_Address` varchar(255) DEFAULT NULL,
  `Location_Rating` varchar(20) DEFAULT NULL,
  `Location_Review` varchar(20) DEFAULT NULL,
  `Location_Photo` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`Location_ID`, `Location_Name`, `Location_Address`, `Location_Rating`, `Location_Review`, `Location_Photo`) VALUES
(1, 'Prima Setapak Condominium', 'Address: Prima Setapak Condominium, Taman Setapak, 53100 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur', '4.5 Rating', '2485 Review', 'LocationPhoto/Prima.png'),
(2, 'PV 13', 'Address: G16,PV13 Platinum Lake Condominium, No.9, Jalan Danau Saujana 1, Setapak, 53300 Kuala Lumpur', '4.2 Rating', '5154 Review', 'LocationPhoto/pv13.jpg'),
(3, 'Setapak Central Mall', 'Address: 67, Jalan Taman Ibu Kota, Taman Danau Kota, 53300 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur', '4.0 Rating', '7553 Review', 'LocationPhoto/setapakcentral.jpg'),
(4, 'Sushi Mentai', 'Address: 126, Jalan Genting Kelang, Taman Danau Kota, 53300 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur', '4.7 Rating', '5020 Review', 'LocationPhoto/sushimentai.jpg'),
(5, 'Tunku Abdul Rahman University College', 'Address: Kampus Utama, Jalan Genting Kelang, 53300 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur', '3.9 Rating', '9844 Review', 'LocationPhoto/tarc.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`Location_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `Location_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
